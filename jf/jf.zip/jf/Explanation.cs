﻿using System;
using System.Collections.Generic;
using System.Text;

namespace jf
{
    class Explanation
    {
        public SymbolTable st = new SymbolTable();
    }
}
